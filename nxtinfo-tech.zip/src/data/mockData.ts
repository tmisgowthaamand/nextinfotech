import { ServiceItem, CaseStudy, IndustryItem, BlogPost, Testimonial, HubLocation } from '../types';

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: 'custom-software',
    title: 'Custom Software Engineering',
    shortDesc: 'Build resilient, scalable, and high-performance bespoke software tailored to your specific business logic and competitive advantages.',
    iconName: 'Code2',
    category: 'Software',
    features: [
      'Modern microservices & event-driven distributed architectures',
      'High-throughput real-time APIs (REST, GraphQL, gRPC)',
      'Legacy software modernizing & cloud re-platforming',
      'Clean Code, TDD, Domain-Driven Design (DDD)'
    ],
    deliverables: [
      'Production-ready backend & frontend codebases',
      'Comprehensive automated test suites (>85% coverage)',
      'CI/CD pipeline configuration & infra scripts',
      'Technical architecture documentation & runbooks'
    ],
    technologies: ['TypeScript', 'Node.js', 'Go', 'Python', 'Rust', 'Java Spring', 'React', 'Next.js'],
    metricHighlight: '3.4x faster time-to-market compared to traditional in-house ramp-up'
  },
  {
    id: 'ai-data',
    title: 'AI, GenAI & Data Intelligence',
    shortDesc: 'Turn raw data into proprietary intelligence with custom LLMs, RAG architectures, vision models, and robust enterprise MLOps.',
    iconName: 'Cpu',
    category: 'AI & Data',
    features: [
      'Enterprise Retrieval-Augmented Generation (RAG) & Vector search',
      'Autonomous AI Agent workflows & Multi-agent orchestration',
      'Domain-specific fine-tuning (Llama 3, Gemini, Mistral)',
      'Scalable real-time streaming data pipelines & lakehouses'
    ],
    deliverables: [
      'Production AI agents with guardrails & latency monitoring',
      'Vector databases (Pinecone, Qdrant, Milvus) deployment',
      'Data extraction & ETL pipelines in dbt and Apache Spark',
      'Compliance & model hallucination evaluation benchmarks'
    ],
    technologies: ['PyTorch', 'Gemini API', 'LangChain', 'LlamaIndex', 'Databricks', 'Snowflake', 'PostgreSQL pgvector', 'Hugging Face'],
    metricHighlight: '62% reduction in manual data processing overhead for clients'
  },
  {
    id: 'cloud-devops',
    title: 'Cloud & DevOps Modernization',
    shortDesc: 'Architect zero-downtime, multi-region cloud infrastructures with automated GitOps, infrastructure-as-code, and strict DevSecOps.',
    iconName: 'Cloud',
    category: 'Cloud & DevOps',
    features: [
      'Cloud-native Kubernetes (EKS, GKE, AKS) orchestration',
      'Infrastructure as Code (Terraform, Pulumi, Ansible)',
      'GitOps pipelines with ArgoCD & GitHub Actions',
      'Cloud cost optimization (FinOps) & auto-scaling clusters'
    ],
    deliverables: [
      'Immutable Infrastructure as Code repository',
      'Comprehensive monitoring & observability with Prometheus/Datadog',
      'Disaster recovery & multi-region failover blueprints',
      'Hardened SOC2 / ISO 27001 compliant cloud topology'
    ],
    technologies: ['AWS', 'Google Cloud', 'Microsoft Azure', 'Docker', 'Kubernetes', 'Terraform', 'ArgoCD', 'Datadog'],
    metricHighlight: '40% average cloud infrastructure cost reduction achieved'
  },
  {
    id: 'dedicated-teams',
    title: 'Dedicated Agile Engineering Pods',
    shortDesc: 'Instantly augment your capacity with pre-vetted, top 1% senior engineering teams that integrate seamlessly into your workflow.',
    iconName: 'Users2',
    category: 'Teams',
    features: [
      'Autonomous cross-functional pods (Lead, Full-Stack, AI, QA, DevOps)',
      'Time zone aligned delivery across Americas, EMEA, and APAC',
      'Direct communication in Slack/Teams and Jira integration',
      'Strict transparency, sprint demos, and weekly velocity reports'
    ],
    deliverables: [
      'Zero onboarding friction — team operational in under 10 business days',
      'Dedicated Scrum Master & Technical Delivery Lead',
      'Full IP and code ownership transferred in real-time',
      'Flexible scale-up and scale-down contracts'
    ],
    technologies: ['Agile / Scrum', 'Jira', 'GitHub', 'GitLab', 'Slack', 'Linear'],
    metricHighlight: '98% client team retention rate with 14-day replacement guarantee'
  },
  {
    id: 'product-design',
    title: 'Digital Product Design & UX/UI',
    shortDesc: 'Design intuitive, high-converting digital interfaces backed by deep user research, design systems, and rapid prototyping.',
    iconName: 'Palette',
    category: 'Software',
    features: [
      'Enterprise Design Systems & Tokenized Component Libraries',
      'User Journey Mapping, Customer Persona & Usability Testing',
      'Interactive Figma prototypes and micro-interaction animations',
      'Accessibility audit conforming to WCAG 2.2 AA standards'
    ],
    deliverables: [
      'Production-ready Figma UI component library',
      'Validated usability test reports & heatmaps',
      'Design tokens synced directly to frontend repositories',
      'Responsive design guidelines for Mobile, Tablet, Desktop'
    ],
    technologies: ['Figma', 'Storybook', 'Tailwind CSS', 'Framer Motion', 'Hotjar', 'Miro'],
    metricHighlight: '+140% improvement in user task completion speed'
  },
  {
    id: 'qa-automation',
    title: 'Quality Engineering & Test Automation',
    shortDesc: 'Eliminate production regressions with end-to-end test automation, performance stress testing, and continuous security audits.',
    iconName: 'ShieldCheck',
    category: 'Cloud & DevOps',
    features: [
      'Automated E2E testing with Playwright & Cypress',
      'API load, stress, and spike testing with k6 and Locust',
      'Static code analysis, SAST/DAST automated vulnerability scans',
      'AI-assisted test generation and self-healing test suites'
    ],
    deliverables: [
      'Automated CI testing matrix running on every pull request',
      'Performance benchmark reports and latency diagnostics',
      'Test coverage dashboards and defect tracking',
      'Security vulnerability remediation plan'
    ],
    technologies: ['Playwright', 'Cypress', 'k6', 'SonarQube', 'Postman', 'Snyk'],
    metricHighlight: '99.9% bug-free releases on production deployment'
  }
];

export const CASE_STUDIES_DATA: CaseStudy[] = [
  {
    id: 'finscale-neobank',
    title: 'Scaling an AI-Powered Open Banking Engine to 4M+ Active Users',
    client: 'FinScale Global Banking',
    industry: 'FinTech',
    heroMetric: '4.8x',
    heroMetricLabel: 'Throughput Increase at 99.999% Uptime',
    summary: 'nxtinfo tech engineered a high-velocity, event-driven ledger architecture and an automated AI fraud detection engine for a next-generation European FinTech unicorn.',
    challenge: 'The client was experiencing severe transaction bottlenecks during peak shopping periods, with legacy monolithic servers incurring 1,200ms latency and high operational costs.',
    solution: 'Designed and deployed an event-driven Go microservices architecture orchestrated on AWS EKS with Kafka streaming, complemented by a sub-10ms real-time AI anomaly detection layer.',
    results: [
      'Processed 12,000+ transactions per second during Black Friday peak',
      'Reduced core transaction latency from 1,200ms to 42ms',
      'Prevented $3.2M in fraudulent transactions within the first 6 months',
      'Compliant with PCI-DSS Level 1 and Open Banking ISO 20022'
    ],
    techStack: ['Go', 'Apache Kafka', 'PostgreSQL', 'AWS EKS', 'Redis Cluster', 'Python / PyTorch', 'Terraform'],
    image: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=1200&q=80',
    testimonial: {
      quote: 'nxtinfo tech delivered what two previous agencies couldn’t. Their engineers felt like our own core staff from day one, and their AI-native acceleration cut our roadmap by 5 months.',
      author: 'Marcus Vance',
      role: 'Chief Technology Officer, FinScale Global',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'
    }
  },
  {
    id: 'medvanguard-ai',
    title: 'HIPAA-Compliant Diagnostic Assistant for 60+ Hospital Networks',
    client: 'MedVanguard Health Informatics',
    industry: 'HealthTech',
    heroMetric: '65%',
    heroMetricLabel: 'Faster Clinical Documentation & Report Turnaround',
    summary: 'Engineered a secure generative AI clinical copilot that ingests electronic health records (EHR) and radiology notes to assist physicians in real-time diagnostics.',
    challenge: 'Physicians were spending over 3.5 hours per day on manual data entry and unstructured documentation, leading to clinician burnout and diagnosis delays.',
    solution: 'Developed an isolated, private LLM pipeline using vector embeddings and FHIR data standards with end-to-end cryptographic audit trails and zero data retention.',
    results: [
      'Adopted by 60+ health networks across the US and UK',
      'Reduced physician administrative paperwork by 2.2 hours daily per doctor',
      '100% HIPAA and GDPR compliant with zero security breaches',
      '99.2% accuracy on medical entity extraction benchmarks'
    ],
    techStack: ['Python', 'FastAPI', 'Gemini Models', 'Qdrant Vector DB', 'React', 'Google Cloud Healthcare API', 'Docker'],
    image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=1200&q=80',
    testimonial: {
      quote: 'The precision and safety checks engineered by nxtinfo tech set a new standard in healthcare AI integration. Our clinical staff adoption rate exceeded 94% within 3 weeks.',
      author: 'Dr. Elena Rostova',
      role: 'VP of Medical Systems, MedVanguard',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80'
    }
  },
  {
    id: 'omnilogix-cloud',
    title: 'Cloud Modernization & Multi-Cloud Migration for Global Logistics',
    client: 'OmniLogix Freight & Supply',
    industry: 'Telecom',
    heroMetric: '$1.4M',
    heroMetricLabel: 'Annual Cloud & Infrastructure Savings',
    summary: 'Modernized a global freight tracking and warehouse management network across 38 distribution centers with cloud-native Kubernetes and real-time IoT telemetry.',
    challenge: 'On-premise legacy data centers suffered from frequent outages and inability to scale dynamically during unpredictable international shipping surges.',
    solution: 'Migrated 40+ legacy services to a multi-cloud Kubernetes setup managed by Terraform IaC with live bidirectional IoT telemetry streams via MQTT.',
    results: [
      'Eliminated 99.8% of infrastructure downtime incidents',
      'Real-time shipment location updates streaming at <500ms latency',
      'Reduced annual cloud & server spend by $1.4M via auto-scaling',
      'Automated disaster recovery failover in less than 30 seconds'
    ],
    techStack: ['Kubernetes', 'Terraform', 'AWS', 'GCP', 'Node.js', 'MQTT', 'InfluxDB', 'Grafana'],
    image: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=1200&q=80',
    testimonial: {
      quote: 'nxtinfo tech turned our complex multi-continent logistics nightmare into an elegant, automated cloud powerhouse without a single minute of customer downtime.',
      author: 'David Chen',
      role: 'Director of Global Infrastructure, OmniLogix',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80'
    }
  },
  {
    id: 'verve-ecommerce',
    title: 'Headless AI-Driven eCommerce Architecture for High-Volume Retailer',
    client: 'Verve Luxury Apparel',
    industry: 'Retail',
    heroMetric: '+38%',
    heroMetricLabel: 'Direct Increase in Checkout Conversion Rate',
    summary: 'Built a headless Shopify Plus & Next.js storefront equipped with personalized AI visual search and dynamic product recommendation engine.',
    challenge: 'Slow page loads (4.8s) and high checkout drop-offs were harming brand reputation and ad spend return on investment.',
    solution: 'Engineered an edge-rendered Next.js application with Tailwind CSS, GraphQL backend, and real-time personalized recommendations powered by predictive AI.',
    results: [
      'Lighthouse performance score boosted from 32 to 98',
      'Sub-800ms page load speeds across all global mobile devices',
      'Conversion rate climbed by 38% within 90 days of launch',
      'Handled 250,000 concurrent shoppers during Black Friday seamlessly'
    ],
    techStack: ['Next.js', 'React', 'TypeScript', 'Tailwind CSS', 'Shopify Plus', 'GraphQL', 'Algolia AI', 'Vercel Edge'],
    image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1200&q=80',
    testimonial: {
      quote: 'The speed and visual polish nxtinfo tech engineered transformed our brand perception completely. Our revenue metrics broke every previous company record.',
      author: 'Sophia Sterling',
      role: 'Chief Digital Officer, Verve Luxury',
      avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=200&q=80'
    }
  }
];

export const INDUSTRIES_DATA: IndustryItem[] = [
  {
    id: 'fintech',
    name: 'FinTech & Banking',
    tagline: 'High-speed, compliant financial engines',
    description: 'We engineer ultra-low latency transaction processing systems, digital wallets, automated fraud prevention, and Open Banking APIs for leading banks and Web3 innovators.',
    icon: 'Landmark',
    solutions: ['Core Banking Modernization', 'AI Fraud Detection', 'PCI-DSS Compliance', 'Sub-millisecond Trading Engines', 'Crypto & Digital Assets'],
    impactMetric: 'Over $4.2B processed securely through our architectures',
    activeClients: 18
  },
  {
    id: 'healthtech',
    name: 'HealthTech & Life Sciences',
    tagline: 'Safe, certified digital healthcare solutions',
    description: 'Empowering hospitals, diagnostic labs, and medical device manufacturers with HIPAA/GDPR-compliant telehealth platforms, EHR integrations, and AI diagnostic aids.',
    icon: 'Stethoscope',
    solutions: ['HIPAA Compliant Cloud', 'AI Medical Copilots', 'EHR / FHIR Integration', 'Patient Telemetry IoT', 'Clinical Trial Platforms'],
    impactMetric: 'Over 2.5M patient records handled with 0 security incidents',
    activeClients: 14
  },
  {
    id: 'telecom',
    name: 'Telecom & Connectivity',
    tagline: 'Carrier-grade distributed infrastructure',
    description: 'Supporting Tier-1 telecom providers with 5G orchestration platforms, real-time CDR analytics, OSS/BSS digital transformations, and edge computing architectures.',
    icon: 'Radio',
    solutions: ['5G Network Slicing Management', 'Real-time Streaming Analytics', 'OSS/BSS Modernization', 'Self-service Customer Portals', 'Edge AI Inference'],
    impactMetric: '10M+ daily events processed with sub-second latency',
    activeClients: 9
  },
  {
    id: 'retail',
    name: 'Retail & eCommerce',
    tagline: 'High-conversion omnichannel commerce',
    description: 'Modernizing global retail with headless commerce architecture, smart inventory forecasting, real-time visual search, and frictionless omnichannel checkout flows.',
    icon: 'ShoppingBag',
    solutions: ['Headless eCommerce', 'AI Personalized Recommendations', 'Supply Chain Visibility', 'Dynamic Pricing Engines', 'Mobile POS Integration'],
    impactMetric: '+35% average conversion lift across retail deployments',
    activeClients: 16
  },
  {
    id: 'saas',
    name: 'High-Tech SaaS & Cloud',
    tagline: 'Multi-tenant scale from seed to IPO',
    description: 'Accelerating venture-backed and enterprise SaaS companies with multi-tenant architectures, usage-based billing, enterprise SSO, and autonomous AI features.',
    icon: 'Layers',
    solutions: ['Multi-tenant Architecture', 'Stripe Billing & Metering', 'SAML/SSO & RBAC', 'AI Feature Integration', 'Automated DevOps & CI/CD'],
    impactMetric: 'Zero downtime achieved across 12 SaaS enterprise migrations',
    activeClients: 22
  },
  {
    id: 'energy',
    name: 'Energy & Smart Utilities',
    tagline: 'IoT monitoring and green tech systems',
    description: 'Engineering smart grid monitoring, predictive maintenance for renewable energy farms, and real-time power distribution analytics for modern utility providers.',
    icon: 'Zap',
    solutions: ['Smart Grid IoT Telemetry', 'Predictive Equipment Maintenance', 'Carbon Tracking Dashboards', 'Renewable Asset Analytics', 'SCADA Modernization'],
    impactMetric: '4.8GW of green energy monitored across client assets',
    activeClients: 8
  }
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: '1',
    title: 'Building Production-Ready RAG Architectures: Lessons from Scaling to 10M Vectors',
    slug: 'production-rag-architectures-10m-vectors',
    category: 'AI & Machine Learning',
    readTime: '6 min read',
    date: 'Aug 14, 2026',
    author: {
      name: 'Dr. Alex Vance',
      role: 'Principal AI Architect at nxtinfo tech',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'
    },
    excerpt: 'Why naive vector search fails in enterprise environments and how hybrid search with semantic rerankers and contextual compression solves accuracy bottlenecks.',
    content: `Enterprise AI initiatives often stumble when moving from prototyping to production. In this technical deep dive, we explore how our engineering teams solved latency, hallucinations, and security compliance when scaling RAG pipelines for Tier-1 enterprise clients.

Key takeaways covered:
1. Combining dense vector embeddings with BM25 sparse keyword indices.
2. Cross-encoder re-ranking to prioritize top-3 relevant context chunks.
3. Role-based document access control (RBAC) at the embedding level.
4. Continuous evaluation with RAGAS metrics to measure faithfulness and answer relevancy.`,
    tags: ['GenAI', 'RAG', 'VectorDB', 'Python', 'Enterprise AI'],
    featured: true
  },
  {
    id: '2',
    title: 'The 2024–2026 DevOps Paradigm: Why Platform Engineering is Replacing Pure DevOps',
    slug: 'platform-engineering-replacing-devops',
    category: 'Cloud & DevOps',
    readTime: '8 min read',
    date: 'Aug 02, 2026',
    author: {
      name: 'Sarah Lindqvist',
      role: 'VP of Cloud & DevOps at nxtinfo tech',
      avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=200&q=80'
    },
    excerpt: 'How Internal Developer Platforms (IDPs) and self-service cloud portals are cutting developer onboarding time from weeks to minutes.',
    content: `As development teams grow, the traditional model of relying on a centralized DevOps team to write Helm charts and Terraform templates becomes an organizational bottleneck.

In this guide, we break down how we build Internal Developer Platforms (IDPs) using Backstage, ArgoCD, and Kubernetes operators to empower software engineers to provision preview environments and deploy securely in under 3 minutes.`,
    tags: ['Platform Engineering', 'Kubernetes', 'DevOps', 'Terraform', 'CI/CD']
  },
  {
    id: '3',
    title: 'Why Starting in 2024 Was Our Greatest Competitive Advantage in Tech Consulting',
    slug: 'born-in-2024-ai-native-advantage',
    category: 'Leadership',
    readTime: '5 min read',
    date: 'Jul 26, 2026',
    author: {
      name: 'Kiran Patel',
      role: 'Co-Founder & CEO at nxtinfo tech',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80'
    },
    excerpt: 'Legacy IT giants are burdened with decades of technical debt and outdated billing models. Here is how nxtinfo tech was built from Day 1 as an AI-native engineering partner.',
    content: `When we launched nxtinfo tech in 2024, our thesis was clear: software engineering was undergoing its biggest shift since the invention of the internet.

Traditional agencies sell hours; we deliver accelerated business outcomes. By equipping all our engineers with AI-assisted workflows, automated test synthesizers, and modern cloud-native toolkits, we deliver in 4 months what used to take 14 months.`,
    tags: ['nxtinfo tech', 'AI-Native', 'Agile', 'Future of Work']
  }
];

export const TESTIMONIALS_DATA: Testimonial[] = [
  {
    id: '1',
    quote: 'nxtinfo tech is the highest quality engineering partner we have collaborated with in the last decade. Their engineers hit the ground running within 48 hours and consistently exceed our sprint velocity targets.',
    clientName: 'Alexander Hayes',
    clientRole: 'Chief Technology Officer',
    company: 'NovaPay Global',
    companyLogoText: 'NOVAPAY',
    rating: 5,
    country: 'United States',
    projectType: 'FinTech Core Modernization'
  },
  {
    id: '2',
    quote: 'The level of technical rigor, architectural foresight, and transparent communication is unparalleled. They not only delivered our AI copilot ahead of schedule, but also trained our internal teams to maintain it.',
    clientName: 'Claire Tremblay',
    clientRole: 'Head of Digital Products',
    company: 'Synergy Health Systems',
    companyLogoText: 'SYNERGY',
    rating: 5,
    country: 'Canada',
    projectType: 'Generative AI Healthcare Platform'
  },
  {
    id: '3',
    quote: 'Our cloud migration was a high-risk multi-million dollar undertaking with zero margin for error. nxtinfo tech executed the entire transition seamlessly without a single minute of downtime.',
    clientName: 'Julian Sterling',
    clientRole: 'VP of Engineering',
    company: 'Verve Logistics International',
    companyLogoText: 'VERVE LOGISTICS',
    rating: 5,
    country: 'United Kingdom',
    projectType: 'Multi-Cloud Migration & Kubernetes'
  }
];

export const HUB_LOCATIONS: HubLocation[] = [
  {
    city: 'San Francisco',
    country: 'United States',
    region: 'North America',
    address: '555 Mission St, Suite 2400, San Francisco, CA 94105',
    engineers: 65,
    timeZone: 'PST / EST',
    isHQ: true
  },
  {
    city: 'London',
    country: 'United Kingdom',
    region: 'Europe / UK',
    address: '100 Bishopsgate, London EC2N 4AG',
    engineers: 80,
    timeZone: 'GMT / BST'
  },
  {
    city: 'Warsaw',
    country: 'Poland (EU Hub)',
    region: 'Central Europe',
    address: 'Rondo Daszyńskiego 1, 00-843 Warsaw',
    engineers: 95,
    timeZone: 'CET'
  },
  {
    city: 'Singapore',
    country: 'Singapore',
    region: 'Asia-Pacific',
    address: '1 Marina Boulevard, #28-00, Singapore 018989',
    engineers: 45,
    timeZone: 'SGT'
  }
];

export const TECH_RADAR_CATEGORIES = [
  {
    name: 'Frontend & Mobile',
    items: ['React 19', 'Next.js 15', 'TypeScript', 'Tailwind CSS', 'Vue 3', 'React Native', 'Flutter', 'Swift', 'Kotlin']
  },
  {
    name: 'Backend & APIs',
    items: ['Node.js', 'Go (Golang)', 'Python / FastAPI', 'Rust', 'Java Spring Boot', 'GraphQL', 'gRPC', 'Kafka']
  },
  {
    name: 'AI, LLM & Data',
    items: ['PyTorch', 'Gemini 2.5/3.0', 'LangChain', 'LlamaIndex', 'Pinecone', 'Qdrant', 'Snowflake', 'Databricks']
  },
  {
    name: 'Cloud & Infrastructure',
    items: ['AWS', 'Google Cloud', 'Microsoft Azure', 'Kubernetes (K8s)', 'Docker', 'Terraform', 'ArgoCD', 'Datadog']
  },
  {
    name: 'Databases & Storage',
    items: ['PostgreSQL', 'MongoDB', 'Redis', 'ClickHouse', 'DynamoDB', 'Supabase', 'Elasticsearch', 'BigQuery']
  }
];

export const TRUST_PARTNERS = [
  { name: 'AWS Premier Tier', badge: 'AWS Partner' },
  { name: 'Google Cloud Partner', badge: 'GCP Certified' },
  { name: 'Microsoft Azure Partner', badge: 'Azure Solutions' },
  { name: 'Snowflake Elite', badge: 'Data Cloud' },
  { name: 'Databricks Partner', badge: 'AI & Data' },
  { name: 'Kubernetes Certified', badge: 'CNCF Member' },
  { name: 'ISO 27001 Certified', badge: 'Security First' },
  { name: 'SOC 2 Type II', badge: 'Audited' }
];
