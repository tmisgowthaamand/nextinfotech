import React, { useState } from 'react';
import { Sparkles, Calculator, Users, Clock, Zap, Check, ArrowRight, ShieldCheck, Download, RefreshCw, Send } from 'lucide-react';
import confetti from 'canvas-confetti';

interface EstimatorToolProps {
  onBookEstimate: (summary: string) => void;
}

export const EstimatorTool: React.FC<EstimatorToolProps> = ({ onBookEstimate }) => {
  const [projectType, setProjectType] = useState<'custom-app' | 'ai-agent' | 'cloud-migration' | 'dedicated-pod'>('custom-app');
  const [industry, setIndustry] = useState<string>('FinTech & Banking');
  const [teamSize, setTeamSize] = useState<number>(4);
  const [seniority, setSeniority] = useState<'Mid-Senior' | 'Senior-Lead' | 'Principal / Elite'>('Senior-Lead');
  const [durationMonths, setDurationMonths] = useState<number>(6);
  
  // Add-ons
  const [aiIntegration, setAiIntegration] = useState<boolean>(true);
  const [cloudDevOps, setCloudDevOps] = useState<boolean>(true);
  const [qaAutomation, setQaAutomation] = useState<boolean>(true);
  const [uiUxDesign, setUiUxDesign] = useState<boolean>(true);

  const [submitted, setSubmitted] = useState<boolean>(false);

  // Rate calculations
  const baseMonthlyPerDev = {
    'Mid-Senior': 7500,
    'Senior-Lead': 9800,
    'Principal / Elite': 12500
  }[seniority];

  let addOnCost = 0;
  if (aiIntegration) addOnCost += 2800;
  if (cloudDevOps) addOnCost += 2200;
  if (qaAutomation) addOnCost += 1800;
  if (uiUxDesign) addOnCost += 2400;

  const estimatedMonthlyBudget = (teamSize * baseMonthlyPerDev) + addOnCost;
  const estimatedTotalProject = estimatedMonthlyBudget * durationMonths;

  // Velocity points estimate
  const sprintPointsPerMonth = teamSize * (seniority === 'Principal / Elite' ? 38 : seniority === 'Senior-Lead' ? 30 : 22);

  const triggerConfetti = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#06b6d4', '#6366f1', '#10b981', '#ffffff']
    });
  };

  const handleSendEstimate = (e: React.FormEvent) => {
    e.preventDefault();
    triggerConfetti();
    setSubmitted(true);
    const summary = `Project: ${projectType} | Industry: ${industry} | Team: ${teamSize} devs (${seniority}) | Duration: ${durationMonths} mo | Est. Monthly: $${estimatedMonthlyBudget.toLocaleString()}`;
    onBookEstimate(summary);
  };

  return (
    <section id="estimator" className="py-24 bg-slate-50/50 border-b border-slate-100 relative">
      {/* Background dot pattern */}
      <div className="absolute inset-0 bg-dot-pattern opacity-5 pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="flex items-center justify-center gap-2">
            <span className="w-10 h-[1px] bg-[#0047FF]"></span>
            <span className="text-xs font-bold text-[#0047FF] tracking-[0.2em] uppercase">
              Transparent Engineering Calculator
            </span>
            <span className="w-10 h-[1px] bg-[#0047FF]"></span>
          </div>
          <h2 className="font-heading text-3xl sm:text-4xl md:text-5xl font-extrabold text-[#1a1a1a] tracking-tight">
            Estimate your software project &{' '}
            <span className="text-[#0047FF]">
              dedicated agile team
            </span>
          </h2>
          <p className="text-slate-500 text-base sm:text-lg">
            Configure your technical scope, seniority tier, and team size. Get instant timeline and budget benchmarks tailored to 2024–2026 engineering standards.
          </p>
        </div>

        {/* Main Interactive Matrix */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start text-left">
          
          {/* Controls Panel (7 Cols) */}
          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-8 shadow-sm">
            
            {/* Step 1: Project Type */}
            <div className="space-y-3">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center justify-between">
                <span>1. Select Core Scope</span>
                <span className="text-[#0047FF] font-semibold">Step 1 of 4</span>
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {[
                  { id: 'custom-app', label: 'Custom App / SaaS', sub: 'Full-stack platform' },
                  { id: 'ai-agent', label: 'AI Copilot / RAG', sub: 'LLMs & Intelligence' },
                  { id: 'cloud-migration', label: 'Cloud Migration', sub: 'K8s & Modernization' },
                  { id: 'dedicated-pod', label: 'Dedicated Pod', sub: 'Staff augmentation' }
                ].map((type) => (
                  <button
                    key={type.id}
                    type="button"
                    onClick={() => setProjectType(type.id as any)}
                    className={`p-3 rounded-lg text-left border transition-all cursor-pointer ${
                      projectType === type.id
                        ? 'bg-slate-900 border-slate-900 text-white shadow-md'
                        : 'bg-slate-50 border-slate-200 text-slate-700 hover:text-slate-900 hover:bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className="text-xs font-bold">{type.label}</div>
                    <div className={`text-[10px] mt-0.5 ${projectType === type.id ? 'text-slate-300' : 'text-slate-500'}`}>{type.sub}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Step 2: Industry Domain */}
            <div className="space-y-3">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center justify-between">
                <span>2. Industry Domain</span>
                <span className="text-[#0047FF] font-semibold">Step 2 of 4</span>
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {['FinTech & Banking', 'HealthTech & Med', 'Telecom & 5G', 'Retail & eCommerce', 'High-Tech SaaS', 'Energy & IoT'].map((ind) => (
                  <button
                    key={ind}
                    type="button"
                    onClick={() => setIndustry(ind)}
                    className={`py-2.5 px-3 rounded-md text-xs font-semibold border text-left transition-all cursor-pointer ${
                      industry === ind
                        ? 'bg-blue-50 border-[#0047FF] text-[#0047FF]'
                        : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-white'
                    }`}
                  >
                    {ind}
                  </button>
                ))}
              </div>
            </div>

            {/* Step 3: Team Configuration */}
            <div className="space-y-6 pt-2 border-t border-slate-100">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center justify-between">
                <span>3. Agile Pod Capacity & Seniority</span>
                <span className="text-[#0047FF] font-semibold">Step 3 of 4</span>
              </label>

              {/* Team Size Slider */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-semibold text-slate-700">
                  <span className="flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-[#0047FF]" />
                    Dedicated Engineers:
                  </span>
                  <span className="text-[#0047FF] font-bold font-mono text-sm">{teamSize} Specialists</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="16"
                  value={teamSize}
                  onChange={(e) => setTeamSize(parseInt(e.target.value))}
                  className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-[#0047FF]"
                />
                <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                  <span>2 (Small squad)</span>
                  <span>6 (Full pod)</span>
                  <span>16+ (Multi-pod stream)</span>
                </div>
              </div>

              {/* Seniority Selector */}
              <div className="space-y-2">
                <div className="text-xs font-semibold text-slate-700">Seniority Profile:</div>
                <div className="grid grid-cols-3 gap-2">
                  {(['Mid-Senior', 'Senior-Lead', 'Principal / Elite'] as const).map((tier) => (
                    <button
                      key={tier}
                      type="button"
                      onClick={() => setSeniority(tier)}
                      className={`p-2.5 rounded-md text-center text-xs font-bold border transition-all cursor-pointer ${
                        seniority === tier
                          ? 'bg-[#0047FF] border-[#0047FF] text-white'
                          : 'bg-slate-50 border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-white'
                      }`}
                    >
                      {tier}
                    </button>
                  ))}
                </div>
              </div>

              {/* Duration Slider */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-semibold text-slate-700">
                  <span className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-[#0047FF]" />
                    Estimated Engagement Horizon:
                  </span>
                  <span className="text-[#0047FF] font-bold font-mono text-sm">{durationMonths} Months</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="18"
                  value={durationMonths}
                  onChange={(e) => setDurationMonths(parseInt(e.target.value))}
                  className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-[#0047FF]"
                />
                <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                  <span>2 Months (MVP sprint)</span>
                  <span>6 Months (Core release)</span>
                  <span>18+ Months (Multi-year scaling)</span>
                </div>
              </div>

            </div>

            {/* Step 4: Technical Add-on Modules */}
            <div className="space-y-3 pt-2 border-t border-slate-100">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center justify-between">
                <span>4. Cross-Functional Add-ons</span>
                <span className="text-[#0047FF] font-semibold">Step 4 of 4</span>
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                
                <button
                  type="button"
                  onClick={() => setAiIntegration(!aiIntegration)}
                  className={`p-3 rounded-lg border text-left flex items-start justify-between cursor-pointer transition-colors ${
                    aiIntegration ? 'bg-blue-50/70 border-[#0047FF] text-slate-900' : 'bg-slate-50 border-slate-200 text-slate-600'
                  }`}
                >
                  <div>
                    <div className="text-xs font-bold text-slate-900">AI / LLM Agent Integration</div>
                    <div className="text-[10px] text-slate-500">RAG pipeline, Gemini, fine-tuning</div>
                  </div>
                  <div className={`h-4 w-4 rounded mt-0.5 flex items-center justify-center ${aiIntegration ? 'bg-[#0047FF] text-white' : 'border border-slate-300'}`}>
                    {aiIntegration && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setCloudDevOps(!cloudDevOps)}
                  className={`p-3 rounded-lg border text-left flex items-start justify-between cursor-pointer transition-colors ${
                    cloudDevOps ? 'bg-blue-50/70 border-[#0047FF] text-slate-900' : 'bg-slate-50 border-slate-200 text-slate-600'
                  }`}
                >
                  <div>
                    <div className="text-xs font-bold text-slate-900">Cloud & DevOps (Terraform/K8s)</div>
                    <div className="text-[10px] text-slate-500">GitOps, auto-scaling & monitoring</div>
                  </div>
                  <div className={`h-4 w-4 rounded mt-0.5 flex items-center justify-center ${cloudDevOps ? 'bg-[#0047FF] text-white' : 'border border-slate-300'}`}>
                    {cloudDevOps && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setQaAutomation(!qaAutomation)}
                  className={`p-3 rounded-lg border text-left flex items-start justify-between cursor-pointer transition-colors ${
                    qaAutomation ? 'bg-blue-50/70 border-[#0047FF] text-slate-900' : 'bg-slate-50 border-slate-200 text-slate-600'
                  }`}
                >
                  <div>
                    <div className="text-xs font-bold text-slate-900">Automated QA & E2E Testing</div>
                    <div className="text-[10px] text-slate-500">Playwright, CI regression suites</div>
                  </div>
                  <div className={`h-4 w-4 rounded mt-0.5 flex items-center justify-center ${qaAutomation ? 'bg-[#0047FF] text-white' : 'border border-slate-300'}`}>
                    {qaAutomation && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setUiUxDesign(!uiUxDesign)}
                  className={`p-3 rounded-lg border text-left flex items-start justify-between cursor-pointer transition-colors ${
                    uiUxDesign ? 'bg-blue-50/70 border-[#0047FF] text-slate-900' : 'bg-slate-50 border-slate-200 text-slate-600'
                  }`}
                >
                  <div>
                    <div className="text-xs font-bold text-slate-900">Product UI/UX & Design System</div>
                    <div className="text-[10px] text-slate-500">Figma tokenized library & UX tests</div>
                  </div>
                  <div className={`h-4 w-4 rounded mt-0.5 flex items-center justify-center ${uiUxDesign ? 'bg-[#0047FF] text-white' : 'border border-slate-300'}`}>
                    {uiUxDesign && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                </button>

              </div>
            </div>

          </div>

          {/* Results Summary Card (5 Cols) */}
          <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-28">
            
            <div className="rounded-2xl bg-white border-2 border-slate-900 p-6 sm:p-8 shadow-xl relative overflow-hidden">
              
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <span className="text-xs uppercase text-slate-900 font-extrabold tracking-wider">
                  nxtinfo tech • Estimate Summary
                </span>
                <span className="px-2 py-0.5 rounded-sm bg-blue-50 text-[#0047FF] text-[10px] font-bold font-mono">
                  EST. 2024 RATES
                </span>
              </div>

              {/* Price Figures */}
              <div className="py-6 space-y-4">
                <div>
                  <span className="text-xs text-slate-500 uppercase tracking-wider font-semibold block">Estimated Monthly Investment</span>
                  <div className="flex items-baseline gap-2 mt-1">
                    <span className="font-heading text-3xl sm:text-4xl font-black text-[#1a1a1a]">
                      ${estimatedMonthlyBudget.toLocaleString()}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">/ month</span>
                  </div>
                </div>

                <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 flex justify-between items-center">
                  <span className="text-xs font-semibold text-slate-600">Total {durationMonths}-Month Horizon:</span>
                  <span className="text-sm font-mono font-black text-[#0047FF]">
                    ${estimatedTotalProject.toLocaleString()} USD
                  </span>
                </div>
              </div>

              {/* Estimated Team Output Metrics */}
              <div className="space-y-3 pb-6 border-b border-slate-100 text-xs">
                <div className="flex justify-between text-slate-700">
                  <span className="text-slate-500 font-medium">Team Composition:</span>
                  <span className="font-bold text-slate-900">{teamSize} Engineers ({seniority})</span>
                </div>
                <div className="flex justify-between text-slate-700">
                  <span className="text-slate-500 font-medium">Sprint Velocity:</span>
                  <span className="font-mono text-[#0047FF] font-bold">~{sprintPointsPerMonth} pts / month</span>
                </div>
                <div className="flex justify-between text-slate-700">
                  <span className="text-slate-500 font-medium">Ramp-Up SLA:</span>
                  <span className="font-bold text-emerald-600">Operational in 10 Business Days</span>
                </div>
                <div className="flex justify-between text-slate-700">
                  <span className="text-slate-500 font-medium">IP Ownership:</span>
                  <span className="font-bold text-slate-900">100% Client Transferred Daily</span>
                </div>
              </div>

              {/* Submission Action */}
              <div className="pt-6 space-y-3">
                {submitted ? (
                  <div className="p-4 rounded-lg bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs text-center space-y-1">
                    <div className="font-bold flex items-center justify-center gap-1.5 text-sm text-emerald-700">
                      <ShieldCheck className="w-4 h-4" />
                      Estimate Registered!
                    </div>
                    <p>Our Solution Architects have received your configuration and will prepare your tailored scope proposal within 24 hours.</p>
                  </div>
                ) : (
                  <button
                    onClick={handleSendEstimate}
                    className="w-full py-4 px-6 rounded-sm bg-[#0047FF] hover:bg-blue-700 text-white font-bold text-xs uppercase tracking-wider shadow-sm transition-colors cursor-pointer flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>LOCK ESTIMATE & REQUEST DISCOVERY</span>
                  </button>
                )}

                <div className="flex items-center justify-center gap-2 text-[11px] text-slate-500 text-center font-medium">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#0047FF]" />
                  <span>No obligation • Mutual NDA signed prior to code review</span>
                </div>
              </div>

            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
