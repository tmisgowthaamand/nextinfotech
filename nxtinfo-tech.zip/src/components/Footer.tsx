import React, { useState } from 'react';
import { HUB_LOCATIONS } from '../data/mockData';
import { Sparkles, ArrowRight, ShieldCheck, Mail, MapPin, Globe, Check, Github, Linkedin, Twitter } from 'lucide-react';

export const Footer: React.FC = () => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail) {
      setSubscribed(true);
    }
  };

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#111625] text-slate-400 border-t border-slate-800 pt-16 pb-12 text-left">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Newsletter & Call to Action */}
        <div className="p-8 sm:p-10 rounded-xl bg-[#171e31] border border-slate-700/80 mb-16 flex flex-col lg:flex-row items-center justify-between gap-8 shadow-lg">
          <div className="space-y-2 max-w-xl">
            <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#0047FF] flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              Subscribe to Engineering Insights
            </span>
            <h3 className="font-heading text-2xl sm:text-3xl font-extrabold text-white">
              Stay ahead of the 2024–2026 software paradigm
            </h3>
            <p className="text-xs sm:text-sm text-slate-300">
              Bi-weekly architectural breakdowns on RAG, Kubernetes GitOps, autonomous agents, and engineering velocity.
            </p>
          </div>

          <div className="w-full lg:w-auto">
            {subscribed ? (
              <div className="p-3.5 rounded-md bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs font-mono flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Thank you for subscribing to nxtinfo tech Insights!</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-2.5">
                <input
                  type="email"
                  required
                  placeholder="Enter your work email"
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  className="px-4 py-3 rounded-md bg-[#0e1320] border border-slate-700 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-[#0047FF] min-w-[260px]"
                />
                <button
                  type="submit"
                  className="px-5 py-3 rounded-sm bg-[#0047FF] hover:bg-blue-600 text-white font-bold uppercase tracking-wider text-xs shadow-md transition-colors cursor-pointer shrink-0"
                >
                  SUBSCRIBE
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Global Delivery Hubs Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 pb-12 border-b border-slate-800">
          {HUB_LOCATIONS.map((hub) => (
            <div key={hub.city} className="space-y-1.5">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <MapPin className="w-3.5 h-3.5 text-[#0047FF]" />
                <span>{hub.city} ({hub.country.split(' ')[0]})</span>
                {hub.isHQ && <span className="text-[9px] px-1.5 py-0.2 rounded-sm bg-[#0047FF] text-white font-bold uppercase">HQ</span>}
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">
                {hub.address}
              </p>
              <div className="text-[11px] text-blue-400 font-mono">
                {hub.engineers}+ Engineers • {hub.timeZone}
              </div>
            </div>
          ))}
        </div>

        {/* Footer Navigation Columns */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 py-12 border-b border-slate-800 text-xs">
          
          {/* Brand Info */}
          <div className="col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="h-8 w-8 rounded-sm bg-[#0047FF] flex items-center justify-center font-black text-sm text-white">
                N
              </div>
              <span className="font-heading font-extrabold text-xl tracking-tight text-white">
                nxtinfo<span className="text-[#0047FF]">.tech</span>
              </span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
              Global AI-native software engineering consultancy founded in 2024. Building custom cloud platforms, autonomous LLM agents, and dedicated agile squads with zero technical debt.
            </p>
            <div className="flex items-center gap-3 text-slate-400 pt-1">
              <span className="p-2 rounded-md bg-[#171e31] hover:text-[#0047FF] hover:bg-slate-800 cursor-pointer transition-colors">
                <Linkedin className="w-4 h-4" />
              </span>
              <span className="p-2 rounded-md bg-[#171e31] hover:text-[#0047FF] hover:bg-slate-800 cursor-pointer transition-colors">
                <Twitter className="w-4 h-4" />
              </span>
              <span className="p-2 rounded-md bg-[#171e31] hover:text-[#0047FF] hover:bg-slate-800 cursor-pointer transition-colors">
                <Github className="w-4 h-4" />
              </span>
            </div>
          </div>

          {/* Services Links */}
          <div className="space-y-3">
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">Services</h4>
            <ul className="space-y-2">
              <li><button onClick={() => scrollTo('services')} className="hover:text-white transition-colors cursor-pointer">Custom Software</button></li>
              <li><button onClick={() => scrollTo('services')} className="hover:text-white transition-colors cursor-pointer">AI & GenAI Solutions</button></li>
              <li><button onClick={() => scrollTo('services')} className="hover:text-white transition-colors cursor-pointer">Cloud & DevOps</button></li>
              <li><button onClick={() => scrollTo('services')} className="hover:text-white transition-colors cursor-pointer">Dedicated Agile Pods</button></li>
              <li><button onClick={() => scrollTo('services')} className="hover:text-white transition-colors cursor-pointer">Product UX/UI Design</button></li>
              <li><button onClick={() => scrollTo('services')} className="hover:text-white transition-colors cursor-pointer">Quality Engineering</button></li>
            </ul>
          </div>

          {/* Industries */}
          <div className="space-y-3">
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">Industries</h4>
            <ul className="space-y-2">
              <li><button onClick={() => scrollTo('industries')} className="hover:text-white transition-colors cursor-pointer">FinTech & Banking</button></li>
              <li><button onClick={() => scrollTo('industries')} className="hover:text-white transition-colors cursor-pointer">HealthTech & Med</button></li>
              <li><button onClick={() => scrollTo('industries')} className="hover:text-white transition-colors cursor-pointer">Telecom & 5G</button></li>
              <li><button onClick={() => scrollTo('industries')} className="hover:text-white transition-colors cursor-pointer">Retail & eCommerce</button></li>
              <li><button onClick={() => scrollTo('industries')} className="hover:text-white transition-colors cursor-pointer">High-Tech SaaS</button></li>
              <li><button onClick={() => scrollTo('industries')} className="hover:text-white transition-colors cursor-pointer">Energy & IoT</button></li>
            </ul>
          </div>

          {/* Company & Tools */}
          <div className="space-y-3">
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">Company & Tools</h4>
            <ul className="space-y-2">
              <li><button onClick={() => scrollTo('why-us')} className="hover:text-white transition-colors cursor-pointer">Why nxtinfo tech (Est. 2024)</button></li>
              <li><button onClick={() => scrollTo('estimator')} className="hover:text-white transition-colors cursor-pointer text-blue-400 font-semibold">Cost & Team Estimator</button></li>
              <li><button onClick={() => scrollTo('ai-scorecard')} className="hover:text-white transition-colors cursor-pointer">AI Readiness Quiz</button></li>
              <li><button onClick={() => scrollTo('case-studies')} className="hover:text-white transition-colors cursor-pointer">Case Studies</button></li>
              <li><button onClick={() => scrollTo('tech-radar')} className="hover:text-white transition-colors cursor-pointer">Technology Radar</button></li>
              <li><button onClick={() => scrollTo('insights')} className="hover:text-white transition-colors cursor-pointer">Insights & Blog</button></li>
            </ul>
          </div>

        </div>

        {/* Bottom copyright & legal */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <div>
            © 2024–2026 nxtinfo tech. All rights reserved. Registered global software consultancy.
          </div>
          <div className="flex items-center gap-6">
            <span className="hover:text-slate-300 cursor-pointer">Privacy Policy</span>
            <span className="hover:text-slate-300 cursor-pointer">Terms of Service</span>
            <span className="hover:text-slate-300 cursor-pointer">Security & Compliance</span>
            <span className="hover:text-slate-300 cursor-pointer">ISO 27001 Certified</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
