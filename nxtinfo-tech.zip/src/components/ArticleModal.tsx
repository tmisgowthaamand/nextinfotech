import React from 'react';
import { BlogPost } from '../types';
import { X, Clock, Calendar, Share2, Tag, ArrowLeft } from 'lucide-react';

interface ArticleModalProps {
  article: BlogPost | null;
  onClose: () => void;
}

export const ArticleModal: React.FC<ArticleModalProps> = ({ article, onClose }) => {
  if (!article) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-900/60 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl bg-white border border-slate-200 rounded-xl shadow-2xl overflow-hidden my-8 max-h-[90vh] flex flex-col text-left">
        
        {/* Header */}
        <div className="p-6 bg-white border-b border-slate-200 flex items-center justify-between sticky top-0 z-20">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-sm bg-blue-50 text-[#0047FF] text-xs font-bold uppercase tracking-wider border border-blue-100">
              {article.category}
            </span>
            <span className="text-xs text-slate-500 font-medium flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              {article.readTime}
            </span>
          </div>
          
          <button
            onClick={onClose}
            className="p-2 rounded-md bg-slate-100 text-slate-500 hover:text-black hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Article Body */}
        <div className="p-6 sm:p-10 space-y-6 overflow-y-auto">
          
          <h1 className="font-heading text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#1a1a1a] leading-tight">
            {article.title}
          </h1>

          {/* Author info */}
          <div className="flex items-center gap-3 py-4 border-y border-slate-100">
            <img
              src={article.author.avatar}
              alt={article.author.name}
              className="w-11 h-11 rounded-full object-cover border border-slate-200"
            />
            <div>
              <div className="text-sm font-bold text-[#1a1a1a]">{article.author.name}</div>
              <div className="text-xs text-slate-500">{article.author.role} • {article.date}</div>
            </div>
          </div>

          {/* Article Excerpt */}
          <div className="p-4 rounded-lg bg-blue-50/70 border border-blue-100 text-sm text-slate-700 font-medium italic">
            {article.excerpt}
          </div>

          {/* Body Content */}
          <div className="text-slate-700 text-sm sm:text-base leading-relaxed space-y-4 whitespace-pre-line font-normal">
            {article.content}
          </div>

          {/* Tags */}
          <div className="pt-6 border-t border-slate-100 space-y-2">
            <div className="text-xs uppercase text-slate-500 font-bold tracking-wider">Topics & Tags:</div>
            <div className="flex flex-wrap gap-2">
              {article.tags.map((tag, i) => (
                <span key={i} className="px-3 py-1 rounded-sm bg-slate-100 text-xs font-semibold text-slate-700 border border-slate-200">
                  #{tag}
                </span>
              ))}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
