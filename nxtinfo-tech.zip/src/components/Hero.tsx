import React from 'react';
import { ArrowRight, Sparkles, ShieldCheck, CheckCircle2, Terminal, Play, Zap, Cpu, Award } from 'lucide-react';

interface HeroProps {
  onOpenEstimator: () => void;
  onOpenContact: () => void;
  onOpenAIQuiz: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenEstimator, onOpenContact, onOpenAIQuiz }) => {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative pt-32 pb-20 md:pt-36 md:pb-24 overflow-hidden bg-white border-b border-slate-100">
      {/* Background radial dot pattern */}
      <div className="absolute inset-0 bg-dot-pattern opacity-10 pointer-events-none -z-10" />
      <div className="absolute top-1/3 right-10 w-96 h-96 bg-[#0047FF] rounded-full blur-[120px] opacity-[0.06] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Core Value Proposition */}
          <div className="lg:col-span-7 space-y-7 text-left">
            
            {/* Top accent tag matching design */}
            <div className="flex items-center gap-2">
              <span className="w-12 h-[1px] bg-[#0047FF]"></span>
              <span className="text-xs font-bold text-[#0047FF] tracking-[0.2em] uppercase">
                Established 2024 • AI-Native Engineering
              </span>
            </div>

            {/* Main Headline */}
            <h1 className="font-heading text-4xl sm:text-5xl md:text-6xl font-extrabold text-[#1a1a1a] tracking-tight leading-[1.1]">
              Engineering <br />
              <span className="text-[#0047FF]">Software Excellence</span> <br />
              at Global Scale.
            </h1>

            {/* Subtext */}
            <p className="text-lg sm:text-xl text-slate-500 max-w-2xl font-normal leading-relaxed">
              We build high-performing engineering teams that accelerate your product development and drive digital transformation through cutting-edge AI architectures, cloud microservices, and dedicated agile pods.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
              <button
                id="hero-start-project-btn"
                onClick={onOpenContact}
                className="inline-flex items-center justify-center gap-2.5 px-8 py-4 bg-[#1a1a1a] hover:bg-black text-white text-sm font-bold rounded-sm tracking-wider uppercase transition-colors shadow-sm cursor-pointer"
              >
                <span>WORK WITH US</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                id="hero-estimator-btn"
                onClick={onOpenEstimator}
                className="inline-flex items-center justify-center gap-2 px-8 py-4 border border-slate-200 hover:border-slate-400 bg-white text-slate-800 text-sm font-bold rounded-sm tracking-wider uppercase transition-colors shadow-sm cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-[#0047FF]" />
                <span>ESTIMATE TEAM & BUDGET</span>
              </button>
            </div>

            {/* Bullet Highlights */}
            <div className="pt-4 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-semibold text-slate-600 border-t border-slate-100">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#0047FF] shrink-0" />
                <span>10-day agile pod onboarding</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#0047FF] shrink-0" />
                <span>100% code & IP ownership</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#0047FF] shrink-0" />
                <span>ISO 27001 & SOC 2 certified</span>
              </div>
            </div>

          </div>

          {/* Right Column: Interactive Visual Console matching design */}
          <div className="lg:col-span-5 relative">
            <div className="relative border border-slate-200 rounded-3xl bg-white shadow-2xl p-7 sm:p-8 overflow-hidden text-left">
              
              {/* Card top bar */}
              <div className="flex justify-between items-center mb-6">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-400"></div>
                  <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
                  <div className="w-3 h-3 rounded-full bg-green-400"></div>
                </div>
                <div className="text-[10px] text-slate-400 font-mono tracking-wider font-bold">
                  PROJECT_STATUS: ACTIVE • v2026
                </div>
              </div>

              {/* Progress and status indicators */}
              <div className="space-y-3 mb-6">
                <div className="h-2 bg-slate-100 w-3/4 rounded-full"></div>
                <div className="h-2 bg-slate-100 w-full rounded-full"></div>
                <div className="h-2 bg-[#0047FF] w-1/2 rounded-full opacity-60"></div>
                <div className="h-2 bg-slate-100 w-5/6 rounded-full"></div>
              </div>

              {/* Stat Boxes */}
              <div className="grid grid-cols-2 gap-4 mb-5">
                <div className="rounded-lg border border-slate-100 bg-slate-50 p-3.5">
                  <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">
                    ENGINEERING VELOCITY
                  </div>
                  <div className="text-2xl font-black text-[#0047FF]">98.4%</div>
                  <div className="text-[10px] text-slate-500 mt-0.5">340% over legacy avg.</div>
                </div>

                <div className="rounded-lg border border-slate-100 bg-slate-50 p-3.5">
                  <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">
                    PRODUCTION UPTIME
                  </div>
                  <div className="text-2xl font-black text-emerald-600">99.9%</div>
                  <div className="text-[10px] text-slate-500 mt-0.5">Zero critical incidents</div>
                </div>
              </div>

              {/* GenAI Tag list */}
              <div className="p-3 rounded-lg border border-slate-100 bg-slate-50 mb-5">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-700 mb-2">
                  <span className="flex items-center gap-1.5">
                    <Cpu className="w-3.5 h-3.5 text-[#0047FF]" />
                    GenAI Architecture Pods
                  </span>
                  <span className="text-[11px] font-mono text-[#0047FF] font-bold">120+ Active</span>
                </div>
                <div className="flex flex-wrap gap-1.5 text-[10px] font-mono font-semibold">
                  <span className="px-2 py-0.5 rounded bg-blue-50 text-[#0047FF] border border-blue-100">RAG</span>
                  <span className="px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-100">Gemini</span>
                  <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-100">FastAPI</span>
                  <span className="px-2 py-0.5 rounded bg-slate-200/70 text-slate-700">K8s GitOps</span>
                </div>
              </div>

              {/* Action in Card */}
              <button
                onClick={onOpenAIQuiz}
                className="w-full py-3 px-4 rounded-md bg-slate-900 hover:bg-[#0047FF] text-white text-xs font-bold uppercase tracking-wider flex items-center justify-between transition-colors cursor-pointer group shadow-sm"
              >
                <span className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-blue-300" />
                  Take AI Readiness Assessment
                </span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </button>

              <div className="absolute -right-20 -bottom-20 w-64 h-64 bg-[#0047FF] rounded-full blur-[80px] opacity-10 pointer-events-none"></div>
            </div>

            {/* Floating badge */}
            <div className="absolute -bottom-4 -left-3 sm:-left-5 p-3 rounded-lg bg-white border border-slate-200 shadow-xl flex items-center gap-3">
              <div className="h-10 w-10 rounded-sm bg-blue-50 text-[#0047FF] flex items-center justify-center font-black text-lg">
                4.9
              </div>
              <div className="text-left">
                <div className="text-xs font-bold text-slate-900 flex items-center gap-1">
                  Clutch Top Rated
                  <Award className="w-3.5 h-3.5 text-amber-500" />
                </div>
                <div className="text-[10px] text-slate-500 font-medium">40+ Verified Enterprise Reviews</div>
              </div>
            </div>

          </div>

        </div>

        {/* Bottom Live Metrics Banner matching design aesthetic */}
        <div className="mt-16 sm:mt-20 pt-8 border-t border-slate-100 grid grid-cols-2 md:grid-cols-4 gap-0 divide-y md:divide-y-0 md:divide-x divide-slate-100 bg-white">
          <div className="flex flex-col justify-center px-6 py-4 text-left">
            <span className="text-3xl font-extrabold text-[#1a1a1a]">45+</span>
            <span className="text-xs text-slate-500 uppercase tracking-widest mt-1 font-semibold">Core Deliveries</span>
            <span className="text-[11px] text-slate-400 mt-0.5">Since 2024 inception</span>
          </div>

          <div className="flex flex-col justify-center px-6 py-4 text-left">
            <span className="text-3xl font-extrabold text-[#1a1a1a]">250+</span>
            <span className="text-xs text-slate-500 uppercase tracking-widest mt-1 font-semibold">Senior Engineers</span>
            <span className="text-[11px] text-slate-400 mt-0.5">Top 1% vetted talent</span>
          </div>

          <div className="flex flex-col justify-center px-6 py-4 text-left">
            <span className="text-3xl font-extrabold text-[#1a1a1a]">12</span>
            <span className="text-xs text-slate-500 uppercase tracking-widest mt-1 font-semibold">Cloud Partners</span>
            <span className="text-[11px] text-slate-400 mt-0.5">AWS, GCP, Azure Tier</span>
          </div>

          <div className="flex flex-col justify-center px-6 py-4 text-left">
            <span className="text-3xl font-extrabold text-[#1a1a1a]">98%</span>
            <span className="text-xs text-slate-500 uppercase tracking-widest mt-1 font-semibold">Client Retention</span>
            <span className="text-[11px] text-slate-400 mt-0.5">Scale without limits</span>
          </div>
        </div>

      </div>
    </section>
  );
};
