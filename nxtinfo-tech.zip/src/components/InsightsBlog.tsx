import React, { useState } from 'react';
import { BLOG_POSTS } from '../data/mockData';
import { BlogPost } from '../types';
import { BookOpen, Clock, ArrowRight, Sparkles, User } from 'lucide-react';

interface InsightsBlogProps {
  onReadArticle: (article: BlogPost) => void;
}

export const InsightsBlog: React.FC<InsightsBlogProps> = ({ onReadArticle }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'AI & Machine Learning', 'Cloud & DevOps', 'Leadership'];

  const filteredPosts = selectedCategory === 'All'
    ? BLOG_POSTS
    : BLOG_POSTS.filter(p => p.category === selectedCategory);

  return (
    <section id="insights" className="py-24 bg-white border-b border-slate-100 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="space-y-3 max-w-2xl text-left">
            <div className="flex items-center gap-2">
              <span className="w-10 h-[1px] bg-[#0047FF]"></span>
              <span className="text-xs font-bold text-[#0047FF] tracking-[0.2em] uppercase">
                Engineering Insights & Research
              </span>
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl md:text-5xl font-extrabold text-[#1a1a1a] tracking-tight">
              Tech radar, architectures &{' '}
              <span className="text-[#0047FF]">
                best practices
              </span>
            </h2>
            <p className="text-slate-500 text-base sm:text-lg">
              Explore deep dives on RAG systems, Kubernetes platform engineering, and modern developer productivity from our senior architects.
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-sm text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-[#1a1a1a] text-white shadow-sm'
                    : 'bg-slate-50 border border-slate-200 text-slate-700 hover:text-black hover:bg-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Posts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {filteredPosts.map((post) => (
            <div
              key={post.id}
              onClick={() => onReadArticle(post)}
              className="p-7 rounded-xl bg-white border border-slate-200 hover:border-slate-300 hover:shadow-xl transition-all flex flex-col justify-between text-left cursor-pointer group"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between text-xs font-medium text-slate-500">
                  <span className="px-2.5 py-0.5 rounded-sm bg-blue-50 text-[#0047FF] border border-blue-100 font-bold uppercase tracking-wider text-[10px]">
                    {post.category}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    {post.readTime}
                  </span>
                </div>

                <h3 className="font-heading text-lg sm:text-xl font-bold text-[#1a1a1a] group-hover:text-[#0047FF] transition-colors leading-snug">
                  {post.title}
                </h3>

                <p className="text-xs sm:text-sm text-slate-600 line-clamp-3 leading-relaxed">
                  {post.excerpt}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <img
                    src={post.author.avatar}
                    alt={post.author.name}
                    className="w-8 h-8 rounded-full object-cover border border-slate-200"
                  />
                  <div>
                    <div className="text-xs font-bold text-[#1a1a1a]">{post.author.name}</div>
                    <div className="text-[10px] text-slate-400">{post.date}</div>
                  </div>
                </div>

                <ArrowRight className="w-4 h-4 text-[#0047FF] group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
