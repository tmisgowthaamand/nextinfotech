import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { PartnerTicker } from './components/PartnerTicker';
import { ServicesSection } from './components/ServicesSection';
import { EstimatorTool } from './components/EstimatorTool';
import { IndustriesSection } from './components/IndustriesSection';
import { CaseStudiesSection } from './components/CaseStudiesSection';
import { CaseStudyModal } from './components/CaseStudyModal';
import { AIReadinessQuiz } from './components/AIReadinessQuiz';
import { WhyUs2024 } from './components/WhyUs2024';
import { TechRadar } from './components/TechRadar';
import { Testimonials } from './components/Testimonials';
import { InsightsBlog } from './components/InsightsBlog';
import { ArticleModal } from './components/ArticleModal';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { CaseStudy, BlogPost, ServiceItem } from './types';

export default function App() {
  const [activeCaseStudy, setActiveCaseStudy] = useState<CaseStudy | null>(null);
  const [activeArticle, setActiveArticle] = useState<BlogPost | null>(null);
  const [selectedServiceForRfp, setSelectedServiceForRfp] = useState<string>('');
  const [estimateSummaryForRfp, setEstimateSummaryForRfp] = useState<string>('');

  const handleSelectService = (service: ServiceItem) => {
    setSelectedServiceForRfp(service.title);
    const contactEl = document.getElementById('contact');
    if (contactEl) contactEl.scrollIntoView({ behavior: 'smooth' });
  };

  const handleStartSimilarCaseStudy = (caseTitle: string) => {
    setEstimateSummaryForRfp(`Similar Architecture Request: ${caseTitle}`);
    const contactEl = document.getElementById('contact');
    if (contactEl) contactEl.scrollIntoView({ behavior: 'smooth' });
  };

  const handleBookEstimate = (summary: string) => {
    setEstimateSummaryForRfp(summary);
    const contactEl = document.getElementById('contact');
    if (contactEl) contactEl.scrollIntoView({ behavior: 'smooth' });
  };

  const handleScheduleRoadmap = (scoreSummary: string) => {
    setEstimateSummaryForRfp(`AI Diagnostic Result: ${scoreSummary}`);
    const contactEl = document.getElementById('contact');
    if (contactEl) contactEl.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToContact = () => {
    const el = document.getElementById('contact');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToEstimator = () => {
    const el = document.getElementById('estimator');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToAIQuiz = () => {
    const el = document.getElementById('ai-scorecard');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-white text-[#1a1a1a] selection:bg-[#0047FF] selection:text-white">
      {/* Navigation Header */}
      <Header
        onOpenEstimator={scrollToEstimator}
        onOpenContact={scrollToContact}
        onOpenAIQuiz={scrollToAIQuiz}
      />

      {/* Main Page Flow */}
      <main>
        {/* 1. Hero Section with Live Stats & CTAs */}
        <Hero
          onOpenEstimator={scrollToEstimator}
          onOpenContact={scrollToContact}
          onOpenAIQuiz={scrollToAIQuiz}
        />

        {/* 2. Partner and Cloud Ecosystem Ticker */}
        <PartnerTicker />

        {/* 3. Core Services with Interactive Tabs */}
        <ServicesSection
          onSelectService={handleSelectService}
          onOpenEstimator={scrollToEstimator}
        />

        {/* 4. Interactive Project & Dedicated Team Cost Estimator */}
        <EstimatorTool onBookEstimate={handleBookEstimate} />

        {/* 5. Domain & Industry Expertise */}
        <IndustriesSection />

        {/* 6. Success Stories / Case Studies with Filter */}
        <CaseStudiesSection onViewCaseStudy={setActiveCaseStudy} />

        {/* 7. Interactive AI Readiness Diagnostic */}
        <AIReadinessQuiz onScheduleRoadmap={handleScheduleRoadmap} />

        {/* 8. Why nxtinfo tech (Founded 2024 AI-Native Advantage & Global Delivery Hubs) */}
        <WhyUs2024 />

        {/* 9. Technology Stack Radar */}
        <TechRadar />

        {/* 10. Verified Client Testimonials */}
        <Testimonials />

        {/* 11. Engineering Insights & Research Articles */}
        <InsightsBlog onReadArticle={setActiveArticle} />

        {/* 12. Contact & RFP Consultation Form */}
        <ContactSection
          initialService={selectedServiceForRfp}
          initialEstimate={estimateSummaryForRfp}
        />
      </main>

      {/* Footer */}
      <Footer />

      {/* Modals */}
      <CaseStudyModal
        caseStudy={activeCaseStudy}
        onClose={() => setActiveCaseStudy(null)}
        onStartSimilar={handleStartSimilarCaseStudy}
      />

      <ArticleModal
        article={activeArticle}
        onClose={() => setActiveArticle(null)}
      />
    </div>
  );
}
