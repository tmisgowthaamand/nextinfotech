export interface ServiceItem {
  id: string;
  title: string;
  shortDesc: string;
  iconName: string;
  category: 'Software' | 'AI & Data' | 'Cloud & DevOps' | 'Teams';
  features: string[];
  deliverables: string[];
  technologies: string[];
  metricHighlight: string;
}

export interface CaseStudy {
  id: string;
  title: string;
  client: string;
  industry: 'FinTech' | 'HealthTech' | 'Telecom' | 'Retail' | 'SaaS' | 'Energy';
  heroMetric: string;
  heroMetricLabel: string;
  summary: string;
  challenge: string;
  solution: string;
  results: string[];
  techStack: string[];
  image: string;
  testimonial?: {
    quote: string;
    author: string;
    role: string;
    avatar: string;
  };
}

export interface IndustryItem {
  id: string;
  name: string;
  tagline: string;
  description: string;
  icon: string;
  solutions: string[];
  impactMetric: string;
  activeClients: number;
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  category: 'AI & Machine Learning' | 'Cloud & DevOps' | 'Software Engineering' | 'Leadership';
  readTime: string;
  date: string;
  author: {
    name: string;
    role: string;
    avatar: string;
  };
  excerpt: string;
  content: string;
  tags: string[];
  featured?: boolean;
}

export interface Testimonial {
  id: string;
  quote: string;
  clientName: string;
  clientRole: string;
  company: string;
  companyLogoText: string;
  rating: number;
  country: string;
  projectType: string;
}

export interface HubLocation {
  city: string;
  country: string;
  region: string;
  address: string;
  engineers: number;
  timeZone: string;
  isHQ?: boolean;
}

export interface EstimatorState {
  projectType: string;
  industry: string;
  teamSize: number;
  seniority: 'Mid-Senior' | 'Senior-Lead' | 'Principal / Elite';
  durationMonths: number;
  aiIntegration: boolean;
  cloudDevOps: boolean;
  qaAutomation: boolean;
  uiUxDesign: boolean;
}
